package com.example.ubitian.bloodbank_modify.CustomClass;

/**
 * Created by Ubitian on 3/1/2017.
 */

public class UserData {
    private String f_name , l_name , blood_group ;

    public UserData(String f_name, String l_name, String blood_group) {
        this.f_name = f_name;
        this.l_name = l_name;
        this.blood_group = blood_group;
    }

    public UserData() {
    }

    public String getF_name() {
        return f_name;
    }

    public void setF_name(String f_name) {
        this.f_name = f_name;
    }

    public String getL_name() {
        return l_name;
    }

    public void setL_name(String l_name) {
        this.l_name = l_name;
    }

    public String getBlood_group() {
        return blood_group;
    }

    public void setBlood_group(String blood_group) {
        this.blood_group = blood_group;
    }
}
