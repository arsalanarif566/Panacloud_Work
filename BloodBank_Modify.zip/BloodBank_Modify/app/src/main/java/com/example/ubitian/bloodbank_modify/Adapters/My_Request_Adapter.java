package com.example.ubitian.bloodbank_modify.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.ubitian.bloodbank_modify.CustomClass.Post_Req_Data;
import com.example.ubitian.bloodbank_modify.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Ubitian on 3/2/2017.
 */

public class My_Request_Adapter extends ArrayAdapter<Post_Req_Data> {

    DatabaseReference database;
    FirebaseAuth mAuth;
    int volu =0;
    String uid , id;
    Button volunteer;

    public My_Request_Adapter(Context context, ArrayList<Post_Req_Data>mylist) {
        super(context, R.layout.my_display,mylist);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = convertView;
        if(v == null){
            v = LayoutInflater.from(getContext()).inflate(R.layout.my_display, parent , false);

        }

        database = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();

        uid = mAuth.getCurrentUser().getUid();

      //  volunteer = (Button)v.findViewById(R.id.volunteer);

        Post_Req_Data post_feed_data = getItem(position);

        TextView Name = (TextView)v.findViewById(R.id.my_name);
        Name.setText("Name: " + post_feed_data.getName());

        TextView group = (TextView)v.findViewById(R.id.my_group);
        group.setText("Blood_Group: " + post_feed_data.getBlood_group());

        TextView unit = (TextView)v.findViewById(R.id.my_units);
        unit.setText("Unit: " + post_feed_data.getUnits());

        TextView country = (TextView)v.findViewById(R.id.my_country);
        country.setText("Country: " + post_feed_data.getCountry());

        TextView city = (TextView)v.findViewById(R.id.my_city);
        city.setText("City: " + post_feed_data.getCity());

        TextView urgency  = (TextView)v.findViewById(R.id.my_urgency);
        urgency.setText("Urgency: " + post_feed_data.getUrgency());

        TextView contact = (TextView)v.findViewById(R.id.my_contact);
        contact.setText("Contact: " + post_feed_data.getContact());

        TextView relation = (TextView)v.findViewById(R.id.my_relation);
        relation.setText("Relation: " + post_feed_data.getRelation());

        return v;
    }
}
