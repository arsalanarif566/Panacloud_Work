package com.example.ubitian.bloodbank_modify.Fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.ubitian.bloodbank_modify.CustomClass.Post_Req_Data;
import com.example.ubitian.bloodbank_modify.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * A simple {@link Fragment} subclass.
 */
public class Post_Requirement extends Fragment {

    String blood_group , choose_country , choose_urgency, choose_city, choose_hospital, choose_relation;
    String[] arr;
    String[] country;
    String [] urgency;
    String[] city;
    String[] relation;
    String[] hospital;
    Post_Req_Data post_req_data;
    DatabaseReference database;
    FirebaseAuth mAuth;
    String id , uid ;
    EditText contact , units ,name;
    Button post;
    int Volunteer= 0;


    public Post_Requirement() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_post__requirement, container, false);

        database = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();
        uid = mAuth.getCurrentUser().getUid();

        contact = (EditText)v.findViewById(R.id.contact);
        units = (EditText)v.findViewById(R.id.units);
        post = (Button)v.findViewById(R.id.post);
        name = (EditText)v.findViewById(R.id.name);


        arr =new String[6];
        arr[0]="A Positive";
        arr[1]="B Positive";
        arr[2]="O Positive";
        arr[3]="A Negative";
        arr[4]="B Negative";
        arr[5]="O Negative";

        country = new String[1];
        country[0] = "Pakistan";

        urgency = new String[3];
        urgency[0] = "Within 1 Day";
        urgency[1] = "Within 2 Day";
        urgency[2] = "Within 3 Day";

        city = new String[4];
        city[0] = "Karachi";
        city[1] = "Lahore";
        city[2] = "Islamabad";
        city[3] = "Quetta";

        hospital = new String[1];
        hospital[0] = "Indus Hospital";

        relation = new String[4];
        relation[0]="Father";
        relation[1]="Mother";
        relation[2]="Brother";
        relation[3]="Sister";


        Spinner spinner1 = (Spinner)v.findViewById(R.id.blood_group);
        Spinner spinner2 = (Spinner)v.findViewById(R.id.urgency);
        Spinner spinner3 = (Spinner)v.findViewById(R.id.country);
        Spinner spinner4 = (Spinner)v.findViewById(R.id.city);
        Spinner spinner5 = (Spinner)v.findViewById(R.id.hospital);
        Spinner spinner6 = (Spinner)v.findViewById(R.id.relation);



        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                blood_group = arr[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }

        });

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                choose_urgency = urgency[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }

        });
        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                choose_country = country[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }

        });
        spinner4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                choose_city = city[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }

        });
        spinner5.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                choose_hospital = hospital[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }

        });
        spinner6.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                choose_relation= relation[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }

        });

        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                id = database.child("Post_Feed_List").push().getKey();

                String my_push =database.push().getKey();
                post_req_data = new Post_Req_Data(my_push,name.getText().toString(),blood_group ,
                        choose_country , choose_city, choose_hospital, choose_urgency, choose_relation,
                        contact.getText().toString(), units.getText().toString(), uid, Volunteer );

                database.child("Post_Feed_List").child(my_push).setValue(post_req_data);

                // Update SignUp
                database.child("User_Info").child(uid).child("My_Post_Feed").child(my_push).setValue(post_req_data);

                Toast.makeText(getContext(), "Post Added", Toast.LENGTH_SHORT).show();

            }
        });

        return v;
    }

}
