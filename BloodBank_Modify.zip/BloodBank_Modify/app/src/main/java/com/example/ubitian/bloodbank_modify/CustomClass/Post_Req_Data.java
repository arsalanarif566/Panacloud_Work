package com.example.ubitian.bloodbank_modify.CustomClass;

/**
 * Created by Ubitian on 3/2/2017.
 */

public class Post_Req_Data {

    private  String post_id ,name ,blood_group,country,city,hospital,urgency,relation,contact,units,uid;
    private int volunteer;

    public Post_Req_Data(String post_id, String name, String blood_group, String country, String city, String hospital, String urgency, String relation, String contact, String units, String uid, int volunteer) {
        this.post_id = post_id;
        this.name = name;
        this.blood_group = blood_group;
        this.country = country;
        this.city = city;
        this.hospital = hospital;
        this.urgency = urgency;
        this.relation = relation;
        this.contact = contact;
        this.units = units;
        this.uid = uid;
        this.volunteer = volunteer;
    }

    public Post_Req_Data() {
    }

    public String getPost_id() {
        return post_id;
    }

    public void setPost_id(String post_id) {
        this.post_id = post_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBlood_group() {
        return blood_group;
    }

    public void setBlood_group(String blood_group) {
        this.blood_group = blood_group;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getHospital() {
        return hospital;
    }

    public void setHospital(String hospital) {
        this.hospital = hospital;
    }

    public String getUrgency() {
        return urgency;
    }

    public void setUrgency(String urgency) {
        this.urgency = urgency;
    }

    public String getRelation() {
        return relation;
    }

    public void setRelation(String relation) {
        this.relation = relation;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getUnits() {
        return units;
    }

    public void setUnits(String units) {
        this.units = units;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public int getVolunteer() {
        return volunteer;
    }

    public void setVolunteer(int volunteer) {
        this.volunteer = volunteer;
    }
}
