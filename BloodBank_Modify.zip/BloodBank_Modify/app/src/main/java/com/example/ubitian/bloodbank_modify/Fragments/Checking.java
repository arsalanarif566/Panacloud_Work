package com.example.ubitian.bloodbank_modify.Fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.ubitian.bloodbank_modify.CustomClass.Post_Req_Data;
import com.example.ubitian.bloodbank_modify.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class Checking extends Fragment {

    TextView chk_name , chk_city;

    public Checking() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_checking, container, false);
        chk_name = (TextView) v.findViewById(R.id.chk_name);

        String value = getArguments().getString("Rcv");
        Log.d("GET_VALUE",value);
        chk_name.setText(value);

//        chk_city = (TextView) v.findViewById(R.id.chk_city);
//
//        Bundle bundle = getArguments();
//        String name_chk = bundle.getString("Name");
//
//        chk_name.setText(name_chk);

        return  v;
    }

}
