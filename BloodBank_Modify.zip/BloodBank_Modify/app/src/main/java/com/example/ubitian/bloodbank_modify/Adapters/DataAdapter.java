package com.example.ubitian.bloodbank_modify.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ubitian.bloodbank_modify.CustomClass.Post_Req_Data;
import com.example.ubitian.bloodbank_modify.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Ubitian on 3/2/2017.
 */

public class DataAdapter extends ArrayAdapter<Post_Req_Data> {

    DatabaseReference database;
    Button volunteer;
    int count;
    String key , user_email;
    Post_Req_Data p;
    TextView volu;
    FirebaseAuth mAuth;

    public DataAdapter(Context context, ArrayList<Post_Req_Data> list) {
        super(context, R.layout.display, list);
        database = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();

        user_email = mAuth.getCurrentUser().getEmail();
    }

    @NonNull
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        View v = convertView;
        if (v == null) {
            v = LayoutInflater.from(getContext()).inflate(R.layout.display, parent, false);
        }

        Post_Req_Data post_req_data = getItem(position);


        volunteer = (Button) v.findViewById(R.id.volunteer);

        TextView email = (TextView) v.findViewById(R.id.dis_email);
        email.setText(user_email);

        TextView name = (TextView) v.findViewById(R.id.dis_name);
        name.setText("Name: " + post_req_data.getName());
        TextView group = (TextView) v.findViewById(R.id.dis_group);
        group.setText("Blood_Group: " + post_req_data.getBlood_group());
        TextView units = (TextView) v.findViewById(R.id.dis_units);
        units.setText("Units: " + post_req_data.getUnits());
        TextView urgency = (TextView) v.findViewById(R.id.dis_urgency);
        urgency.setText("Urgency: " + post_req_data.getUrgency());
        final TextView country = (TextView) v.findViewById(R.id.dis_country);
        country.setText("Country: " + post_req_data.getCountry());
        TextView city = (TextView) v.findViewById(R.id.dis_city);
        city.setText("City: " + post_req_data.getCity());
        TextView hospital = (TextView) v.findViewById(R.id.dis_hospital);
        hospital.setText("Hospital: " + post_req_data.getHospital());
        TextView relation = (TextView) v.findViewById(R.id.dis_relation);
        relation.setText("Relation With patient: " + post_req_data.getRelation());
        TextView contact = (TextView) v.findViewById(R.id.dis_contact);
        contact.setText("Contact_No: " + post_req_data.getContact());
        volu = (TextView) v.findViewById(R.id.dis_volunteer);
        volu.setText("Volunteers: " + post_req_data.getVolunteer());

        volunteer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                database.child("Post_Feed_List").addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                        p = dataSnapshot.getValue(Post_Req_Data.class);

                        Post_Req_Data pos = getItem(position);
                        String val = pos.getPost_id();

                        Log.d("","PostID: " + val);

                        count = p.getVolunteer();

                        count = count + 1;

                        Log.d("","Volunteer:" + count);

                        Map<String, Object> childUpdates = new HashMap<>();
                            childUpdates.put("volunteer", count);
                            database.child("Post_Feed_List").child(val).updateChildren(childUpdates);

                    }

                    @Override
                    public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                    }

                    @Override
                    public void onChildRemoved(DataSnapshot dataSnapshot) {

                    }

                    @Override
                    public void onChildMoved(DataSnapshot dataSnapshot, String s) {

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });

                // another Way to retrieve Data from Loop in value Event listner..

//                database.child("Post_Feed_List").addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(DataSnapshot dataSnapshot) {
//
//
//
//                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
//                            Log.d("", "onDataChange: "+snapshot.getValue().toString()+" key "+ snapshot.getKey());
//                            Post_Req_Data p = snapshot.getValue(Post_Req_Data.class);
//                            xyz = snapshot.getKey();
//
//                            abc = p.getVolunteer();
//
//                            Map<String, Object> childUpdates = new HashMap<>();
//                            childUpdates.put("volunteer", abc);
//                            database.child("Post_Feed_List").child(xyz).updateChildren(childUpdates);
//
//                        }
//
//                        abc = abc + 1;
//
//                    }
//
//                    @Override
//                    public void onCancelled(DatabaseError databaseError) {
//
//                    }
//                });

            }
        });

        return v;
    }
}
