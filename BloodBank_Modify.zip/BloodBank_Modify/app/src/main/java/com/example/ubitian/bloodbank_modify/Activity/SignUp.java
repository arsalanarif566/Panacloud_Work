package com.example.ubitian.bloodbank_modify.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.ubitian.bloodbank_modify.CustomClass.UserData;
import com.example.ubitian.bloodbank_modify.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUp extends AppCompatActivity {

    EditText f_name,l_name, reg_email, reg_pass;
    Button register;
    DatabaseReference database;
    FirebaseAuth mAuth;
    String user , password, uid ,group;
    ProgressDialog dialog;
    UserData userdata;
    String[] arr;
    FirebaseAuth.AuthStateListener authStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        arr =new String[6];
        arr[0]="A_Positive";
        arr[1]="B_Positive";
        arr[2]="O_Positive";
        arr[3]="A_Negative";
        arr[4]="B_Negative";
        arr[5]="O_Negative";

        f_name = (EditText)findViewById(R.id.f_name);
        l_name = (EditText)findViewById(R.id.l_name);
        reg_email = (EditText)findViewById(R.id.register_email);
        reg_pass = (EditText)findViewById(R.id.register_pass);

        register = (Button)findViewById(R.id.register);

        dialog = new ProgressDialog(this);

        database = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();

        authStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if(mAuth.getCurrentUser()!= null){
                    uid = mAuth.getCurrentUser().getUid();

                    database.child("User_Info").push().getKey();
                    userdata = new UserData(f_name.getText().toString() , l_name.getText().toString() , group );
                    database.child("User_Info").child(uid).setValue(userdata);

                    Toast.makeText(SignUp.this, "User Registered", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(SignUp.this , MainActivity.class));
                }
            }
        };


        Spinner spinner = (Spinner)findViewById(R.id.planets_spinner);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                group = arr[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(SignUp.this, "You Have Select No Blood Group", Toast.LENGTH_SHORT).show();
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });
    }
    protected void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(authStateListener);
    }

    private void registerUser() {
        user = reg_email.getText().toString();
        password = reg_pass.getText().toString();

        if(TextUtils.isEmpty(user) || TextUtils.isEmpty(password)){
            Toast.makeText(SignUp.this, "Email Or Password is Empty", Toast.LENGTH_SHORT).show();
            return;
        }

        dialog.setMessage("Registering..");
        dialog.show();

        reg_email.setText("");
        reg_pass.setText("");

        mAuth.createUserWithEmailAndPassword(user , password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    dialog.dismiss();
                    Toast.makeText(SignUp.this, "User Registered..", Toast.LENGTH_SHORT).show();

                }
                else if (!task.isSuccessful()){
                    dialog.dismiss();
                    Toast.makeText(SignUp.this, "User Not Registered", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}
