package com.example.ubitian.bloodbank_modify.Fragments;


import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.ubitian.bloodbank_modify.Adapters.DataAdapter;
import com.example.ubitian.bloodbank_modify.CustomClass.Post_Req_Data;
import com.example.ubitian.bloodbank_modify.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

import static com.example.ubitian.bloodbank_modify.R.id.post;


/**
 * A simple {@link Fragment} subclass.
 */
public class Post_Feed extends Fragment {

    DatabaseReference database;
    FirebaseAuth mAuth;
    ListView listView;
    ArrayList <Post_Req_Data> list;
    FragmentTransaction fragmentTransaction;
    DataAdapter dataAdapter;
    Post_Req_Data p;

    public Post_Feed() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        final View v =inflater.inflate(R.layout.fragment_post__feed, container, false);

        database = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();

        listView = (ListView)v.findViewById(R.id.listview);
        list = new ArrayList<>();
        dataAdapter = new DataAdapter(getContext(), list);
        listView.setAdapter(dataAdapter);


     //   comment = (Button)v.findViewById(R.id.comment);

        database.child("Post_Feed_List").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                p = dataSnapshot.getValue(Post_Req_Data.class);
                list.add(p);
                dataAdapter.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                getFragmentManager().beginTransaction().replace(R.id.content_main , new Checking()).commit();

//                fragmentTransaction.replace(R.id.content_main, new Checking());
//                fragmentTransaction.commit();

                Checking checking = new Checking();
                Bundle bundle = new Bundle();

                Post_Req_Data post = dataAdapter.getItem(position);

                String send_name = post.getName();
                bundle.putString("Rcv",send_name);

                Log.d("","GETNAME" + send_name);

                checking.setArguments(bundle);

//                bundle.putString("Blood Group: " , p.getBlood_group());
//                bundle.putString("City: " , p.getCity());
//                bundle.putString("Contact: " , p.getContact());
//                bundle.putString("Country: " , p.getCountry());
//                bundle.putString("Hospital: " , p.getHospital());
//                bundle.putString("Relation With Patient: " , p.getRelation());
//                bundle.putString("Units: " , p.getUnits());
//                bundle.putString("Urgency: " , p.getUrgency());

            }
        });

        return v;
    }
}
