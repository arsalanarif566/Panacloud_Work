package com.example.ubitian.bloodbank_modify.Fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.ubitian.bloodbank_modify.Adapters.My_Request_Adapter;
import com.example.ubitian.bloodbank_modify.CustomClass.Post_Req_Data;
import com.example.ubitian.bloodbank_modify.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 */
public class MyRequest extends Fragment {


    DatabaseReference database;
    FirebaseAuth mAuth;
    ListView listView;
    ArrayList<Post_Req_Data> mylist;
    Post_Req_Data post_feed_data;
    String uid,id;
    int vol = 0;
    My_Request_Adapter myAdapter;

    public MyRequest() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View v =inflater.inflate(R.layout.fragment_my_request, container, false);

        database = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();
        uid = mAuth.getCurrentUser().getUid();

        listView = (ListView)v.findViewById(R.id.my_listview);
        mylist = new ArrayList<>();
        myAdapter = new My_Request_Adapter(getContext(), mylist);
        listView.setAdapter(myAdapter);


        database.child("User_Info").child(uid).child("My_Post_Feed").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                Post_Req_Data p = dataSnapshot.getValue(Post_Req_Data.class);
                mylist.add(p);
                myAdapter.notifyDataSetChanged();

            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getContext(), "You Clicked", Toast.LENGTH_SHORT).show();
            }
        });

        return v;

    }

}
