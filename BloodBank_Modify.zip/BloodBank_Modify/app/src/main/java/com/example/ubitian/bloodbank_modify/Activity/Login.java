package com.example.ubitian.bloodbank_modify.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ubitian.bloodbank_modify.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class Login extends AppCompatActivity {

    Toolbar toolbar;
    Button login;
    EditText email , pass;
    DatabaseReference database;
    FirebaseAuth mAuth;
    String user_id , pass_id;
    ProgressDialog dialog;
    TextView signUp;
    FirebaseAuth.AuthStateListener authStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        toolbar = (Toolbar) findViewById(R.id.toolbar_login);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("LoginActivity");

        dialog = new ProgressDialog(this);
        database = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();

        authStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if(mAuth.getCurrentUser()!= null){
                    startActivity(new Intent(Login.this , MainActivity.class));
                }
            }
        };

        email = (EditText)findViewById(R.id.etemail);
        pass = (EditText)findViewById(R.id.pass);
        signUp = (TextView)findViewById(R.id.signUp);

        login = (Button)findViewById(R.id.login);

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login.this,SignUp.class));
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userlogin();
            }
        });
    }
    protected void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(authStateListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (authStateListener != null) {
            mAuth.removeAuthStateListener(authStateListener);
        }
    }

    private void userlogin() {
        user_id = email.getText().toString();
        pass_id = pass.getText().toString();

        if(TextUtils.isEmpty(user_id) || TextUtils.isEmpty(pass_id)){
            Toast.makeText(Login.this, "Email Or Password is Empty", Toast.LENGTH_SHORT).show();
            return;
        }

        dialog.setMessage("Signing In");
        dialog.show();

        mAuth.signInWithEmailAndPassword(user_id , pass_id).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(!task.isSuccessful()){
                    dialog.dismiss();
                    Toast.makeText(Login.this, "Email Or Password Is Incorrect", Toast.LENGTH_SHORT).show();
                }
                else{
                    dialog.dismiss();
                }
            }
        });
    }
}
