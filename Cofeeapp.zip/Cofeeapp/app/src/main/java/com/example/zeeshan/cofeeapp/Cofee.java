package com.example.zeeshan.cofeeapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Checkable;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class Cofee extends AppCompatActivity {

    CheckBox normal,special;

    int quantity=0;
    int normal_c= 20;
    int special_c= 40;
    int total;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cofee);
    }

    public void minus(View view){
       TextView textView = (TextView) findViewById(R.id.display);
        if(quantity<=0){
            textView.setText("0");
        }
        else if(quantity>0){
                 quantity = quantity-1;
            textView.setText(Integer.toString(quantity));
        }
        }

    public void add(View view){
        TextView textView = (TextView) findViewById(R.id.display);
        quantity=quantity+1;
        textView.setText(Integer.toString(quantity));
    }


    public void order(View v){

        normal = (CheckBox) findViewById(R.id.checkbox1);
        special = (CheckBox) findViewById(R.id.checkbox2);

        TextView textView = (TextView) findViewById(R.id.amount);

        if(normal.isChecked()){
            total = quantity*normal_c;
            textView.setText(Integer.toString(total));
        }
        else
        if(special.isChecked()){
            total = quantity*special_c;

            textView.setText(Integer.toString(total));
            textView.setTextSize(35);

        }
        Toast.makeText(getApplicationContext(),"Your Total Amount iS " + total , Toast.LENGTH_LONG).show();

    }

    }


