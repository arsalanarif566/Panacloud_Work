package com.example.ubitian.imagestorage;

import android.content.Context;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.firebase.ui.storage.images.FirebaseImageLoader;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Ubitian on 2/16/2017.
 */

public class dataAdapter extends ArrayAdapter<Data>  {
    Data mydata;
    DatabaseReference database;
    StorageReference ref;

    public dataAdapter(Context context, ArrayList<Data> list) {
        super(context,R.layout.display, list);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;

        if(v == null){
            v = LayoutInflater.from(getContext()).inflate(R.layout.display,parent,false);

        }

        database = FirebaseDatabase.getInstance().getReference();
        mydata = getItem(position);

        ImageView img1 = (ImageView)v.findViewById(R.id.img);
        img1.setImageURI(Uri.parse(mydata.getUrl()));

        Glide.with(getContext())
                .using(new FirebaseImageLoader())
                .load(ref)
                .into(img1);

        return v;
    }
}
