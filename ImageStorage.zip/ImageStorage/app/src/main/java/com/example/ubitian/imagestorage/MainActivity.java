package com.example.ubitian.imagestorage;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    StorageReference reference;
    FirebaseStorage storage;
    Button gallery, camera;
    ProgressDialog dialog;
    ImageView imageView;
    ArrayList <Data> list;
    GridView gv;
    ArrayAdapter <Data> dataAdapter;
    DatabaseReference database;
    Data mydata;
    String id, path;


    private static final int GALLERY_INTENT = 2;
    private static final int CAMERA_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        reference = storage.getInstance().getReference();
        database = FirebaseDatabase.getInstance().getReference();


        dialog = new ProgressDialog(this);

        gallery = (Button)findViewById(R.id.gallery);
        camera = (Button)findViewById(R.id.camera);


        gv = (GridView)findViewById(R.id.gridView);

        list = new ArrayList<>();
        dataAdapter = new dataAdapter(this, list);
        gv.setAdapter(dataAdapter);


        gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent, GALLERY_INTENT);
            }
        });

        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, CAMERA_REQUEST_CODE);
            }
        });


        database.child("details").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                Data forget = dataSnapshot.getValue(Data.class);
                list.add(forget);
                dataAdapter.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        //-------------------Code Goes Here...-------------------
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == GALLERY_INTENT && resultCode == RESULT_OK){
            dialog.setMessage("Uploading image...");
            dialog.show();

            Uri uri = data.getData();
            StorageReference filepath = reference.child("Images").child(uri.getLastPathSegment());

            filepath.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    dialog.dismiss();

                    Uri downloadUri = taskSnapshot.getDownloadUrl();
                    path = downloadUri.toString();

                    id = database.child("Details").push().getKey();
                    mydata = new Data(path);
                    database.child("details").child(id).setValue(mydata);
                    Toast.makeText(MainActivity.this, "Upload Successfully..", Toast.LENGTH_SHORT).show();

                }


            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(MainActivity.this, "Uploading Failed..", Toast.LENGTH_SHORT).show();

                }
            });

        }

         else if(requestCode == CAMERA_REQUEST_CODE ){

            dialog.setMessage("Uploading image...");
            dialog.show();

            Uri uri = data.getData();
            StorageReference filepath = reference.child("Images").child(uri.getLastPathSegment());
            filepath.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    dialog.dismiss();

                    Uri downloadUri = taskSnapshot.getDownloadUrl();
                    path = downloadUri.toString();
                    Picasso.with(MainActivity.this).load(downloadUri).fit().centerCrop().into(imageView);

                    id = database.child("Details").push().getKey();
                    mydata = new Data(path);
                    database.child("details").child(id).setValue(mydata);
                    Toast.makeText(MainActivity.this, "Upload Successfully..", Toast.LENGTH_SHORT).show();

                    imageView.setImageDrawable(null);

                    Toast.makeText(MainActivity.this, "Uploading Finish..", Toast.LENGTH_SHORT).show();
                }

            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(MainActivity.this, "Uploading Failed..", Toast.LENGTH_SHORT).show();

                }
            });

        }
    }

}
