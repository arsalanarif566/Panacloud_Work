package com.example.ubitian.imagestorage;

/**
 * Created by Ubitian on 2/16/2017.
 */

public class Data {


    private String url;

    public Data(String url) {

        this.url = url;
    }

    public Data() {
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
